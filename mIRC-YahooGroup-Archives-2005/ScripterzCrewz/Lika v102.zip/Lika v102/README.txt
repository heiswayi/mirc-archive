Kaau ader apa-apa yang nak tanya aku pasal script nie.. 
korang leh masuk Webnet
Kemudian join channel WAR #tisya
Ataupun cari aku yg pakai nick Nalika
++++++++++++++++++++++++++++++++++++++++++++++++++++++++
Kalau korang nak hack pun hack lah... RIP
Ambo tak kisah pasal ambo nie ore baik....
RIP lah biar jadi script korang tapi...
INGAT! Hanya untuk buat sementara waktu nie jas...
Malas aku nak BUBUH Ripguard Format,
Nayo korang nanti tak pasal-pasal KOMPUTER korang DEATH
Hehe...
++++++++++++++++++++++++++++++++++++++++++++++++++++++++
Script name : Lika v.... ( Tok Ingat )
Author : Nalika
Time Create : 1/4 Hari
E-mel ? : noriential_2004@yahoo.com
Team ? : ( ...suka ati aku la nak masuk team apo... )
Members : Banyak sangat susah dibilang dgn JARI
++++++++++++++++++++++++++++++++++++++++++++++++++++++++
* Ader banyak lagi script serupa ngan nie aku buat cuma..
Yang nie aku buat utk PROTECTION jer...